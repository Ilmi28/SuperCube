from .RubiksCube import RubiksCube
from .PocketCube import PocketCube
from .NCube import NCube